import base64
import hashlib
import json
import os
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, Request, Form, UploadFile, File, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel, Field

from gemini_utils import generate_recommendations, generate_jewelry_recommendations

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "pocketsmart.db"
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

app = FastAPI(title="PocketSmart AI", version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            planner TEXT NOT NULL,
            input_json TEXT NOT NULL,
            result_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    conn.commit()
    conn.close()


@app.on_event("startup")
def startup():
    init_db()


def create_token(user_id: int):
    expires = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    return jwt.encode({"sub": str(user_id), "exp": expires}, SECRET_KEY, algorithm=ALGORITHM)


def get_current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        return None
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload.get("sub"))
    except (JWTError, TypeError, ValueError):
        return None

    conn = db()
    user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    return dict(user) if user else None


def require_user(request: Request):
    user = get_current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Please login first.")
    return user


class PlannerRequest(BaseModel):
    budget: float = Field(gt=0)
    preferences: str = ""
    details: str = ""


def save_history(user_id, planner, payload, result):
    conn = db()
    conn.execute(
        "INSERT INTO history(user_id, planner, input_json, result_json, created_at) VALUES (?, ?, ?, ?, ?)",
        (user_id, planner, json.dumps(payload), json.dumps(result),
         datetime.utcnow().isoformat(timespec="seconds"))
    )
    conn.commit()
    conn.close()


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {
        "request": request,
        "user": get_current_user(request)
    })


@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})


@app.post("/register")
def register(name: str = Form(...), email: str = Form(...), password: str = Form(...)):
    if len(password) < 6:
        return RedirectResponse("/register?error=Password%20must%20be%20at%20least%206%20characters", status_code=303)

    conn = db()
    try:
        conn.execute(
            "INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",
            (name.strip(), email.strip().lower(), pwd_context.hash(password),
             datetime.utcnow().isoformat(timespec="seconds"))
        )
        conn.commit()
    except sqlite3.IntegrityError:
        conn.close()
        return RedirectResponse("/register?error=Email%20already%20registered", status_code=303)
    conn.close()
    return RedirectResponse("/login?registered=1", status_code=303)


@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.post("/login")
def login(email: str = Form(...), password: str = Form(...)):
    conn = db()
    user = conn.execute("SELECT * FROM users WHERE email = ?", (email.strip().lower(),)).fetchone()
    conn.close()

    if not user or not pwd_context.verify(password, user["password_hash"]):
        return RedirectResponse("/login?error=Invalid%20email%20or%20password", status_code=303)

    response = RedirectResponse("/dashboard", status_code=303)
    response.set_cookie("access_token", create_token(user["id"]), httponly=True, samesite="lax")
    return response


@app.get("/logout")
def logout():
    response = RedirectResponse("/", status_code=303)
    response.delete_cookie("access_token")
    return response


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    user = require_user(request)
    conn = db()
    rows = conn.execute(
        "SELECT * FROM history WHERE user_id=? ORDER BY id DESC LIMIT 10",
        (user["id"],)
    ).fetchall()
    conn.close()

    history = []
    for row in rows:
        history.append({
            "planner": row["planner"],
            "created_at": row["created_at"],
            "result": json.loads(row["result_json"])
        })

    return templates.TemplateResponse("dashboard.html", {
        "request": request, "user": user, "history": history
    })


@app.get("/planner/{planner}", response_class=HTMLResponse)
def planner_page(request: Request, planner: str):
    if planner not in {"home", "party", "jewelry"}:
        raise HTTPException(404)
    return templates.TemplateResponse(f"{planner}_planner.html", {
        "request": request,
        "user": get_current_user(request)
    })


@app.post("/generate-home")
async def generate_home(data: PlannerRequest, request: Request):
    user = require_user(request)
    result = generate_recommendations(
        planner="home",
        budget=data.budget,
        preferences=data.preferences,
        details=data.details
    )
    save_history(user["id"], "home", data.model_dump(), result)
    return result


@app.post("/generate-party")
async def generate_party(data: PlannerRequest, request: Request):
    user = require_user(request)
    result = generate_recommendations(
        planner="party",
        budget=data.budget,
        preferences=data.preferences,
        details=data.details
    )
    save_history(user["id"], "party", data.model_dump(), result)
    return result


@app.post("/generate-jewelry", response_class=JSONResponse)
async def generate_jewelry(
    request: Request,
    budget: float = Form(...),
    occasion: str = Form(""),
    style: str = Form(""),
    outfit: str = Form(""),
    image: Optional[UploadFile] = File(None)
):
    user = require_user(request)

    image_bytes = None
    image_mime = None
    if image and image.filename:
        image_bytes = await image.read()
        image_mime = image.content_type or "image/jpeg"

    result = generate_jewelry_recommendations(
        budget=budget,
        occasion=occasion,
        style=style,
        outfit=outfit,
        image_bytes=image_bytes,
        image_mime=image_mime
    )

    payload = {
        "budget": budget,
        "occasion": occasion,
        "style": style,
        "outfit": outfit,
        "image_uploaded": bool(image_bytes)
    }
    save_history(user["id"], "jewelry", payload, result)
    return result


@app.get("/history")
def history(request: Request):
    user = require_user(request)
    conn = db()
    rows = conn.execute(
        "SELECT * FROM history WHERE user_id=? ORDER BY id DESC",
        (user["id"],)
    ).fetchall()
    conn.close()
    return {
        "history": [
            {
                "id": r["id"],
                "planner": r["planner"],
                "created_at": r["created_at"],
                "input": json.loads(r["input_json"]),
                "result": json.loads(r["result_json"])
            } for r in rows
        ]
    }


@app.get("/session-info")
def session_info(request: Request):
    user = get_current_user(request)
    return {
        "logged_in": bool(user),
        "user_id": user["id"] if user else None,
        "name": user["name"] if user else None
    }


@app.get("/session-data")
def session_data(request: Request):
    user = require_user(request)
    conn = db()
    count = conn.execute(
        "SELECT COUNT(*) AS count FROM history WHERE user_id=?", (user["id"],)
    ).fetchone()["count"]
    conn.close()
    return {"user_id": user["id"], "recommendation_count": count}


@app.get("/recommendations-details/{record_id}")
def recommendation_details(record_id: int, request: Request):
    user = require_user(request)
    conn = db()
    row = conn.execute(
        "SELECT * FROM history WHERE id=? AND user_id=?",
        (record_id, user["id"])
    ).fetchone()
    conn.close()
    if not row:
        raise HTTPException(404, "Recommendation not found")
    return {
        "planner": row["planner"],
        "input": json.loads(row["input_json"]),
        "result": json.loads(row["result_json"])
    }
