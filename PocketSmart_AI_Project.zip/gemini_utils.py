import json
import os
from typing import Optional

try:
    from google import genai
    from google.genai import types
except ImportError:
    genai = None
    types = None

API_KEY = os.getenv("GEMINI_API_KEY")
MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")


def fallback(planner: str, budget: float, details: str):
    if planner == "home":
        categories = [
            ("Lighting", 0.12), ("Furniture", 0.48),
            ("Decor", 0.20), ("Fans/Utilities", 0.20)
        ]
    elif planner == "party":
        categories = [
            ("Food & Catering", 0.45), ("Decoration", 0.20),
            ("Venue", 0.25), ("Entertainment", 0.10)
        ]
    else:
        categories = [
            ("Necklace", 0.40), ("Earrings", 0.25),
            ("Bangles/Bracelet", 0.20), ("Other", 0.15)
        ]

    return {
        "planner": planner,
        "budget": budget,
        "source": "local fallback",
        "summary": f"Sample budget plan generated for: {details or 'your requirements'}",
        "budget_allocation": [
            {"category": name, "amount": round(budget * pct, 2)}
            for name, pct in categories
        ],
        "recommendations": [
            {
                "name": f"Budget-friendly {name}",
                "category": name,
                "estimated_price": round(budget * pct, 2),
                "platform": platform,
                "reason": "Fits the allocated budget and requested category."
            }
            for (name, pct), platform in zip(
                categories, ["Amazon", "IKEA", "Flipkart", "Amazon"]
            )
        ],
        "note": "These are demo recommendations. Connect a real product/vendor API for live prices and availability."
    }


def _extract_json(text: str):
    text = text.strip()
    if text.startswith("```"):
        text = text.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start:end + 1])
    raise ValueError("Gemini did not return valid JSON")


def _call_gemini(prompt: str, image_bytes: Optional[bytes] = None, image_mime: Optional[str] = None):
    if not API_KEY or genai is None:
        return None

    client = genai.Client(api_key=API_KEY)
    contents = [prompt]

    if image_bytes:
        contents.append(types.Part.from_bytes(
            data=image_bytes,
            mime_type=image_mime or "image/jpeg"
        ))

    response = client.models.generate_content(
        model=MODEL,
        contents=contents,
        config=types.GenerateContentConfig(
            temperature=0.4,
            response_mime_type="application/json"
        )
    )
    return _extract_json(response.text)


def generate_recommendations(planner: str, budget: float, preferences: str, details: str):
    prompt = f"""
You are PocketSmart AI, a budget-aware recommendation assistant.

Planner: {planner}
Budget: INR {budget}
Preferences: {preferences}
Details: {details}

Create a practical plan that stays within the total budget.
Return ONLY valid JSON with this exact structure:
{{
  "planner": "{planner}",
  "budget": {budget},
  "summary": "short summary",
  "budget_allocation": [
    {{"category":"...", "amount":0}}
  ],
  "recommendations": [
    {{
      "name":"...",
      "category":"...",
      "estimated_price":0,
      "platform":"Amazon/Flipkart/IKEA/Swiggy/Zomato/OYO/Other",
      "reason":"..."
    }}
  ],
  "note":"..."
}}

Do not invent live availability. Treat prices as estimates unless connected to a live API.
"""
    try:
        result = _call_gemini(prompt)
        if result:
            result["source"] = "Gemini"
            return result
    except Exception as exc:
        print("Gemini error:", exc)

    return fallback(planner, budget, details)


def generate_jewelry_recommendations(
    budget: float,
    occasion: str,
    style: str,
    outfit: str,
    image_bytes: Optional[bytes] = None,
    image_mime: Optional[str] = None
):
    prompt = f"""
You are PocketSmart AI's Jewelry Budget Planner.

Budget: INR {budget}
Occasion: {occasion}
Preferred style: {style}
Outfit description: {outfit}

If an outfit image is attached, use it only to identify broad color/style coordination.
Recommend jewelry that fits the budget.

Return ONLY valid JSON:
{{
  "planner":"jewelry",
  "budget":{budget},
  "summary":"short summary",
  "outfit_analysis":"brief color/style observations or 'No image supplied'",
  "recommendations":[
    {{
      "name":"...",
      "category":"...",
      "estimated_price":0,
      "platform":"Amazon/Flipkart/Other",
      "reason":"..."
    }}
  ],
  "note":"..."
}}
Do not claim exact live prices or availability.
"""
    try:
        result = _call_gemini(prompt, image_bytes, image_mime)
        if result:
            result["source"] = "Gemini"
            return result
    except Exception as exc:
        print("Gemini jewelry error:", exc)

    result = fallback("jewelry", budget, f"{occasion} / {style}")
    result["outfit_analysis"] = "Demo mode: no AI image analysis available."
    return result
