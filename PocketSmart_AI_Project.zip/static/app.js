function esc(x) {
  return String(x ?? "").replace(/[&<>"']/g, m => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[m]));
}

function renderResult(data) {
  const el = document.getElementById("result");
  let html = `<div class="result"><h2>Recommendations</h2>
    <p>${esc(data.summary)}</p>`;

  if (data.outfit_analysis) {
    html += `<div class="notice"><b>Outfit analysis:</b> ${esc(data.outfit_analysis)}</div>`;
  }

  if (data.budget_allocation?.length) {
    html += `<h3>Budget Allocation</h3><div class="grid">`;
    for (const x of data.budget_allocation) {
      html += `<div class="card"><b>${esc(x.category)}</b><div>₹${Number(x.amount).toLocaleString()}</div></div>`;
    }
    html += `</div>`;
  }

  html += `<h3>Suggested Options</h3><div class="grid">`;
  for (const x of (data.recommendations || [])) {
    html += `<div class="card">
      <h3>${esc(x.name)}</h3>
      <p>${esc(x.category)}</p>
      <p><b>Estimated:</b> ₹${Number(x.estimated_price || 0).toLocaleString()}</p>
      <p><b>Platform:</b> ${esc(x.platform)}</p>
      <p>${esc(x.reason)}</p>
    </div>`;
  }
  html += `</div><div class="notice">${esc(data.note)}</div></div>`;
  el.innerHTML = html;
}

async function generate(planner) {
  const budget = Number(document.getElementById("budget").value);
  const preferences = document.getElementById("preferences").value;
  const details = document.getElementById("details").value;

  if (!budget || budget <= 0) return alert("Enter a valid budget.");

  const res = await fetch(`/generate-${planner}`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({budget, preferences, details})
  });

  const data = await res.json();
  if (!res.ok) return alert(data.detail || "Something went wrong.");
  renderResult(data);
}

async function generateJewelry() {
  const form = new FormData();
  form.append("budget", document.getElementById("budget").value);
  form.append("occasion", document.getElementById("occasion").value);
  form.append("style", document.getElementById("style").value);
  form.append("outfit", document.getElementById("outfit").value);

  const image = document.getElementById("image").files[0];
  if (image) form.append("image", image);

  const res = await fetch("/generate-jewelry", {method:"POST", body:form});
  const data = await res.json();
  if (!res.ok) return alert(data.detail || "Something went wrong.");
  renderResult(data);
}
