# PocketSmart AI

A FastAPI + Gemini budget recommendation assistant based on the supplied project document.

## Features

- User registration/login/logout
- JWT cookie authentication
- Home Interior Planner
- Party Budget Planner
- Jewelry Planner
- Optional outfit image upload for jewelry
- Gemini-powered JSON recommendations
- SQLite recommendation history
- Session info/history endpoints
- Responsive HTML/CSS/JavaScript UI
- Local fallback recommendations when Gemini is not configured

The project follows the document's described routes such as `/generate-home`,
`/generate-party`, `/generate-jewelry`, `/register`, `/login`, `/logout`,
`/token`/session concepts, `/session-info`, `/session-data`, `/history`, and
`/recommendations-details`. The supplied document describes FastAPI in the later
implementation milestones.

## Setup

### 1. Create environment

Windows:
```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:
```bash
python3 -m venv venv
source venv/bin/activate
```

### 2. Install packages

```bash
pip install -r requirements.txt
```

### 3. Configure Gemini

Copy `.env.example` to `.env` and put your API key in:

```text
GEMINI_API_KEY=your_key
```

`GEMINI_MODEL` can be changed if your Google AI account exposes a different
current Gemini model.

If no key is supplied, the app still runs using demo/fallback recommendations.

### 4. Run

```bash
uvicorn app:app --reload
```

Open:

http://127.0.0.1:8000

## API

- `POST /generate-home`
- `POST /generate-party`
- `POST /generate-jewelry`
- `POST /register`
- `POST /login`
- `GET /logout`
- `GET /session-info`
- `GET /session-data`
- `GET /history`
- `GET /recommendations-details/{record_id}`

FastAPI Swagger documentation:

http://127.0.0.1:8000/docs

## Notes

The project uses estimated/demo product information. Live Amazon, Flipkart,
IKEA, Swiggy, Zomato or OYO inventory should only be displayed after connecting
the appropriate official APIs/partner feeds. This prevents the application from
pretending that a generated recommendation is a live listing.
